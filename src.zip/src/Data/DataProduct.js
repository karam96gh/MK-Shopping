export const DataProduct = [


   {
      id: 4,
      img: require("../../src/image/IMG-20241215-WA0006.jpg"),
      MultiImage: [
         require("../../src/image/IMG-20241215-WA0006.jpg"),
      ],
      productName: "حليب فرندو",
      ProductDesraption: "حليب لذيذ ومثالي للعائلة والأطفال.",
      ProductDesraptionAlt: "حليب فرندو بمذاق شهي مثالي لوجبة خفيفة مليئة بالطاقة والنكهة. يُنصح به كخيار صحي للعائلة والأطفال.",
      companyId: 3,
   }
   ,
   {
      id: 13,
      img: require("../../src/image/milk3ch.jpg"),
      MultiImage: [
         require("../../src/image/milk3ch.jpg"),
      ],
      productName: "حليب المستقبل بنكهة الشوكولا",
      ProductDesraption: "حليب بنكهة الشوكولا من حليب المستقبل، يقدم لك تجربة ة.",
      ProductDesraptionAlt: "تناول حليب المستقبل بنكهة الشوكولاتة، واستمتع بمذاقها الغني مع فوائد الحليب الطازج. طاقة لذيذة ومغذية تناسب الجميع في أي وقت.",
      companyId: 3,
   },

   {
      id: 5,
      img: require("../../src/image/matah.jpg"),
      MultiImage: [
         require("../../src/image/matah.jpg"),
      ],
      productName: "متة",
      ProductDesraption: "متة لذيذة ومنعشة بنكهة مميزة تمنحك نشاطاً وحيوية.",
      ProductDesraptionAlt: "متة طبيعية ذات طعم منعش وغني بالطاقة، مثالية لاستراحة قصيرة تمنحك الحيوية والتركيز طوال اليوم.",
      companyId: 4,
   },
   {
      id: 6,
      img: require("../../src/image/greentea.jpg"),
      MultiImage: [
         require("../../src/image/greentea.jpg"),
      ],
      productName: "شاي أخضر",
      ProductDesraption: "شاي أخضر طازج وصحي، يساعد في الاسترخاء وتحسين الهضم.",
      ProductDesraptionAlt: "شاي أخضر نقي ومفيد لصحتك. يساعد في تحسين الهضم والراحة النفسية بفضل مكوناته الطبيعية.",
      companyId: 4,
   },
   {
      id: 7,
      img: require("../../src/image/tona.jpg"),
      MultiImage: [
         require("../../src/image/tona.jpg"),
      ],
      productName: "تونا",
      ProductDesraption: "تونا عالية الجودة، غنية بالبروتين، مثالية للوجبات السريعة.",
      ProductDesraptionAlt: "تونا مغذية وطازجة توفر خياراً صحياً وسريع التحضير للوجبات، مثالية للطعام المتوازن والنظام الغذائي.",
      companyId: 4,
   },






   // البقية تماثل هذا النمط...


];
