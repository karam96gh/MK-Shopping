export const DataCompany = [
   {
      NameCompany: " شركة حميدان    ",
      id: 3,
      Logo: require("../../src/image/Screenshot 2024-12-10 155858.png"),
      // الوصف لا يتجاوز ال 15 كلمة تقريبا  110 حرف يتضن المسافات 
      Descraption: " شركة حميدان تقدم حليب منكه بأصناف متنوعة، بجودة عالية وطعم لذيذ يناسب جميع الأذواق",
      // الصورة حصرا 1.1
      img: require("../../src/image/Screenshot 2024-12-10 155858.png"),
      to: "...رؤية المزيد",
      mobile: "963940415498",
      ImgOfFooter: require("../../src/image/Screenshot 2024-12-10 155858.png"),
      TypeOfCompany: "food",
   },


   {
      id: 4,
      NameCompany: "شركة عمي الحاج ",
      Logo: require("../../src/image/logo1.jpg"),
      Descraption: "شركة عمي الحاج تقدم مجموعة مميزة من المنتجات ذات الجودة العالية: الرز، المتة، التونا، الشاي، والقهوة",
      img: require("../../src/image/logo1.jpg"),
      to: "...رؤية المزيد",
      mobile: "963941899671",
      ImgOfFooter: require("../../src/image/footer.jpg"),
      TypeOfCompany: "food",
   },
   {
      id: 5,
      NameCompany: "معرض سيارات الدروبي ",
      Logo: require("../../src/image/galery.jpg"),
      Descraption: "معرض الدروبي: وجهتك المثالية لأحدث السيارات بأداء متميز، تصاميم عصرية، وخدمات عالية الجودة.",
      img: require("../../src/image/galery.jpg"),
      to: "...رؤية المزيد",
      mobile: "963941899671",
      ImgOfFooter: require("../../src/image/galery.jpg"),
      TypeOfCompany: "Cars",
   },
]
