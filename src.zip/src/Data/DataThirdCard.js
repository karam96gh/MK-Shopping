export const DataThirdCard = [
   {
      id: 5,
      img: require("../image/high quality.png"),
      title: "جودة مضمونة",
      descraption: "نحن نلتزم بتقديم منتجات عالية الجودة وفقًا لأعلى معايير التصنيع",
      companyId: 4,
   },
   {
      id: 6,
      img: require("../image/etfak.jpg"),
      title: "شراكات تجارية",
      descraption: "نحن نبحث عن شراكات استراتيجية مع الشركات المحلية والدولية لتحقيق النمو المشترك",
      companyId: 4,
   },
   {
      id: 7,
      img: require("../image/ebtkar.jpg"),
      title: "ابتكار مستمر",
      descraption: "نواصل الاستثمار في البحث والتطوير لتقديم حلول مبتكرة في جميع مجالاتنا",
      companyId: 4,
   }

]