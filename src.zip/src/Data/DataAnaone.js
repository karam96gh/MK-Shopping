export const DataAnaone = [
   {
      nameAnaone: " خصم %80 ",
      img: require("../image/1734482716199.jpg"),
      Descraption: "MK_Shopping تعلن عن حسومات تصل الى 50% لأول 50 شركة تريد ان تنضم للمنصة ",
      ComapnyId: " ",
      AnaoneAwoner: "",
   }]