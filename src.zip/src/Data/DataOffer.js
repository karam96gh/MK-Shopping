export const DataOffer = [
   {
      Id: 1,
      CompanyId: 3, // يرتبط بشركة "حميدان"
      Img: require("../../src/image/car.jpg"),
      Title: "سورنتو",
      descraption: "سيارة سورنتو جميلة جدا لون احمل موديل 2015",
      OldPrice: "10000$",
      OfferValue: "4%",
      NewPrice: "5000$",
      MultiImage: [
         require("../../src/image/car.jpg"),
         require("../../src/image/kabsahrize.jpg"),
         require("../../src/image/car.jpg"),
      ],
      OfferType: "cars", // نوع العرض: أغذية
   },
   {
      Id: 2,
      CompanyId: 3, // يرتبط بشركة "حميدان"
      Img: require("../../src/image/milk3ch.jpg"),
      Title: "عرض",
      descraption: "مع كل 100 طرد حليب 4 طرود مجاناً",
      OldPrice: "100",
      OfferValue: "4%",
      NewPrice: "50",
      MultiImage: [
         require("../../src/image/kabsahrize.jpg"),
         require("../../src/image/kabsahrize.jpg"),
         require("../../src/image/kabsahrize.jpg"),
      ],
      OfferType: "food", // نوع العرض: أغذية
   },
   {
      Id: 3,
      CompanyId: 3, // يرتبط بشركة "حميدان"
      Img: require("../../src/image/milk3ch.jpg"),
      Title: "فلافل",
      descraption: "مع كل 100 طرد حليب 4 طرود مجاناً",
      OldPrice: "100",
      OfferValue: "4%",
      NewPrice: "50",
      MultiImage: [
         require("../../src/image/kabsahrize.jpg"),
         require("../../src/image/kabsahrize.jpg"),
         require("../../src/image/kabsahrize.jpg"),
      ],
      OfferType: "food", // نوع العرض: أغذية
   },
   {
      Id: 4,
      CompanyId: 3, // يرتبط بشركة "حميدان"
      Img: require("../../src/image/milk3ch.jpg"),
      Title: "شيش طاوق",
      descraption: "مع كل 100 طرد حليب 4 طرود مجاناً",
      OldPrice: "100",
      OfferValue: "4%",
      NewPrice: "50",
      MultiImage: [
         require("../../src/image/kabsahrize.jpg"),
         require("../../src/image/kabsahrize.jpg"),
         require("../../src/image/kabsahrize.jpg"),
      ],
      OfferType: "food", // نوع العرض: أغذية
   },

];